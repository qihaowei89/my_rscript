"print.npmc" <-
function(x, ...)
{
  print(x$test, ...)
}
